package com.avatarbot.mobile.legacy;

/** Immutable values mapped only onto existing fields of the user-supplied farm2x.Config.
 * IDs are game catalog identifiers, NOT guaranteed valid on a current live server.
 */
public final class LegacyAdvancedSetup {
    public final int preferredSeedId, targetLandCount;
    public final int fishingMap, fishingArea, fishingBaitId, fishingRodId;
    public final int diamondSellDurationMin, diamondSellIntervalMs;

    public LegacyAdvancedSetup() {
        this(-1, 0, 14, -1, 448, 442, 3, 200);
    }
    public LegacyAdvancedSetup(int preferredSeedId, int targetLandCount,
        int fishingMap, int fishingArea, int fishingBaitId, int fishingRodId,
        int diamondSellDurationMin, int diamondSellIntervalMs) {
        this.preferredSeedId = preferredSeedId;
        this.targetLandCount = targetLandCount;
        this.fishingMap = fishingMap;
        this.fishingArea = fishingArea;
        this.fishingBaitId = fishingBaitId;
        this.fishingRodId = fishingRodId;
        this.diamondSellDurationMin = diamondSellDurationMin;
        this.diamondSellIntervalMs = diamondSellIntervalMs;
        validate();
    }
    private static void between(String name, int value, int min, int max) {
        if (value < min || value > max) throw new IllegalArgumentException(name + " out of supported range");
    }
    public void validate() {
        between("preferredSeedId",preferredSeedId,-1,65535);
        between("targetLandCount",targetLandCount,0,100);
        between("fishingMap",fishingMap,0,999);
        between("fishingArea",fishingArea,-1,99);
        between("fishingBaitId",fishingBaitId,0,65535);
        between("fishingRodId",fishingRodId,0,65535);
        between("diamondSellDurationMin",diamondSellDurationMin,1,30);
        between("diamondSellIntervalMs",diamondSellIntervalMs,200,5000);
    }
}
