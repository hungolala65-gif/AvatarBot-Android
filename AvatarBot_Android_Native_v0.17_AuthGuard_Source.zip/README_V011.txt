AvatarBot Android v0.11 — source build candidate

Bản mới so với v0.10:
- Tùy chỉnh chu kỳ nghỉ giữa các vòng Auto theo tài khoản: 15, 30, 60, 120, 300 giây
- Đồng bộ tùy chọn mới với Android Keystore và JAR farm2x.Config.loopDelayMs
- Kiểm thử offline xác nhận ánh xạ đúng chu kỳ, bác bỏ giá trị không hợp lệ
- Giữ nguyên các nút Test Login, Chạy, Dừng và cơ chế Foreground Service trước đó
- Thêm .github/workflows/build-apk.yml để build từ mã nguồn (không phụ thuộc ZIP cũ)
- Đối chiếu riêng khả năng bản PC và Android tại docs/RELEASE_READINESS_V011.md

Lưu ý: Không có file APK v0.11 build xong trong gói này. V0.11 đã test Go, Kotlin parser, Java ME trên server giả lập, CHƯA build Gradle Android hoặc kiểm thử game thật. Nếu GitHub hết bị khóa, đẩy NỘI DUNG (không chỉ ZIP) của dự án lên repo Private rồi chạy build-apk.yml trong Actions. Không đăng tài khoản/mật khẩu/token thật lên repository.
